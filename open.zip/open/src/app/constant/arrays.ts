export const activateHeaderNavigation = (currentPage: string) => {
  HEADER_NAVIGATIONS.forEach(element => {
    if (element.currentPage == currentPage) {
      element.isClassActive = true;
    } else {
      element.isClassActive = false;
    }
  });
}

export const PAGES_NAMES = {
  PRODUCTS: 'PRODUCTS',
  SOLUTIONS: 'SOLUTIONS',
  PRICING: 'PRICING'
}

export const HEADER_NAVIGATIONS = [
  { name: 'Products', currentPage: PAGES_NAMES.PRODUCTS, isClassActive: false },
  { name: 'Solutions', currentPage: PAGES_NAMES.SOLUTIONS, isClassActive: false },
  { name: 'Pricing', currentPage: PAGES_NAMES.PRICING, isClassActive: false }
]

export const CARD_INFO = (side) => {
  if (side == 'LEFT') {
    return [
      { image: '../../assets/images/icon1.png', tittle: 'Quick cash disbursement', content: 'Get terms loans that your business need within 72 hrs' },
      { image: '../../assets/images/icon2.png', tittle: 'Low-interest rate', content: 'Achieve your financial goals with an amazing interest rate starting at 13% per annum' },
      { image: '../../assets/images/icon3.png', tittle: 'Zero Paperwork', content: 'Get started instantly by submitting only your basic details & bank statements' }
    ]
  } else {
    return [
      { image: '../../assets/images/icon4.png', tittle: 'Ace your business finances', content: 'Manage banking, accounting & everything in between, on one platform' },
      { image: '../../assets/images/icon5.png', tittle: 'Loans to fight COVID-19', content: 'Zero EMI for first 3 months on Back-to-Business loans of upto 1 lakh' }
    ]
  }
}

export const SLIDER_RANGE = {
  INTERVAL: 1000,
  MIN_LIMIT: 100000,
  MAX_LIMIT: 300000,
  MAX_LENGTH: 5
}

export const TENURE_PERIOD = [
  { name: "6 Months", value: "6" },
  { name: "1 Year", value: "12" },
  { name: "2 Year", value: "24" },
  { name: "3 Year", value: "36" },
  { name: "4 Year", value: "48" },
  { name: "5 Year", value: "60" }
];
