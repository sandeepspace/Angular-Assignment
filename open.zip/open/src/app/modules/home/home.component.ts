import { Component, OnInit } from '@angular/core';
import { CARD_INFO } from '../../constant/arrays';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  leftCards = CARD_INFO('LEFT');
  rightCards = CARD_INFO('RIGHT');


  constructor() { }

  ngOnInit(): void {
  }

}
