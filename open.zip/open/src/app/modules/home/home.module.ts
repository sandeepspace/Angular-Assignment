import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { Routes, RouterModule } from '@angular/router';
import { HeaderModule } from '../../global-modules/header/header.module';
import { CardComponent } from './_components/card/card.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSliderModule } from '@angular/material/slider';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { EligibilityCalFormComponent } from './_components/eligibility-cal-form/eligibility-cal-form.component';
import { InrModule } from '../../pipes/inr/inr.module';
import { NumberModule } from '../../directives/number/number.module';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';


const inrRoutes: Routes = [
  {
    path: '', component: HomeComponent
  }
];

@NgModule({
  declarations: [HomeComponent, CardComponent, EligibilityCalFormComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(inrRoutes),
    HeaderModule,
    ReactiveFormsModule,
    MatSliderModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    NumberModule,
    MatSlideToggleModule,
    InrModule
  ]
})
export class HomeModule { }
