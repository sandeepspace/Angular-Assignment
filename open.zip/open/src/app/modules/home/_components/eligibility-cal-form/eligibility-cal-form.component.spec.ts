import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityCalFormComponent } from './eligibility-cal-form.component';

describe('EligibilityCalFormComponent', () => {
  let component: EligibilityCalFormComponent;
  let fixture: ComponentFixture<EligibilityCalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EligibilityCalFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityCalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
