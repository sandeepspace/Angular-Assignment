import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SLIDER_RANGE, TENURE_PERIOD } from '../../../../constant/arrays';

@Component({
  selector: 'open-eligibility-cal-form',
  templateUrl: './eligibility-cal-form.component.html',
  styleUrls: ['./eligibility-cal-form.component.scss']
})

export class EligibilityCalFormComponent implements OnInit {
  eligibilityForm: FormGroup;
  sliderMinMaxLimits = SLIDER_RANGE;
  tenurePeriods = TENURE_PERIOD;
  @Output() formCriteria = new EventEmitter();

  constructor(
    private _fb: FormBuilder
  ) { }

  ngOnInit() {
    this.createForm()
  }

  createForm() {
    this.eligibilityForm = this._fb.group({
      monthlyIncome: [],
      monthlyExpenses: [],
      tenurePeriod: [this.tenurePeriods[0].value],
      isExistingLoan: [false],
      existingLoan: []
    })
  }

  get controls() { return this.eligibilityForm.controls } // return all form controls

  formatLabel(value: number) {
    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }
    return value;
  }

  onSlideChange(value: boolean) {
    if (!value) {
      this.controls.existingLoan.setValue('');
    }
  }
}
