import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'open-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  @Input() cardData: any;

  constructor() { }

  ngOnInit(): void {
  }

}
