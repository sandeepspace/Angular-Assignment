import { Component, OnInit, HostListener } from '@angular/core';
import { HEADER_NAVIGATIONS } from '../../constant/arrays';

@Component({
  selector: 'open-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  headerNavigations = HEADER_NAVIGATIONS;
  fixedHeader = false;

  constructor() { }

  @HostListener("window:scroll", ['$event'])
  onWindowScroll() {
    var doc = document.documentElement;
    var top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    if (top > 50) {
      this.fixedHeader = true;
    } else {
      this.fixedHeader = false;
    }
  }

  ngOnInit() {
  }

  changeNavigations(currentPage: string) {

  }


  openNav() { }

  closeNav() { }

}
